import os
import sys
import math
import copy
import numpy as np
import pandas as pd
import itertools
import HelperFunctions as HF
from pandas import DataFrame


#adaboost model learner
#S: example features
#y: correct classification of example
#L: number of learners
def adaboost(data, features, y, L, depth):
    W = [] # weights for each feature, for each weak learner
    Alpha = [] # weight for each weak learner
    # data = data1
    M = len(data) # number of examples

    # #initialize weights D, with uniform distribution initially
    # D = [] #weights for each example, for each learner
    # D.append(np.ones(N)/N)
    data['D'] = np.ones(M)/M

    for le in range(L):
        h = HF.learn(data, features, y, depth, mode='adaboost') #get model
        err, errorlog = calcErr(h,data,features,y) #find err of model
        alpha = .5*math.log((1 - err)/err) #calc weight

        print('alpha: {}, err: {}'.format(alpha, err))
        newData = copy.deepcopy(data)
        #calculations for D[l+1]
        i = 0 #example ind
        for ind,ex in data.iterrows():
        # for err in errorlog: 
            # Dex = 0
            if (errorlog[i]): #guessed wrong
                # Dex = D[l][i]*math.exp(alpha)
                newData['D'][ind] = ex['D']*math.exp(alpha)
            else: #guessed right
                # Dex = D[l][i]*math.exp(-alpha)
                newData['D'][ind] = ex['D']*math.exp(-alpha)
            # print('prevD: {}, newD: {}, alpha: {}, err: {}'.format(ex['D'],newData['D'][ind],alpha, errorlog[i]))
            # Dl.append(Dex) #save D[l+1][ex]
            i += 1 #increment for next loop
        data = newData

        #normalize D
        # print('Sum of D before: {0}'.format(data.sum(axis=0)['D']))
        Norm = data.sum(axis=0)['D'] #TODO: make sure this is how you normalize
        data['D'] = data['D']/Norm
        # print('Sum of D after: {0}'.format(data.sum(axis=0)['D']))
        # D.append(Dl) #save D[l+1]
        W.append(h)  #save model for learner
        Alpha.append(alpha) #save vote weight for learner

    return W, Alpha


#calculate the weighted err, returns a log of the results too
#for the log, 0 if guess is correct, 1 if wrong
def calcErr(h,data,features,y):
    errorlog = []
    err = 0

    # i = 0 #example ind
    for ind,ex in data.iterrows():
        # print('\n\n')
        # print(ex)
        if (HF.useTree(h,ex) == ex[y]):
            errorlog.append(0) 
        else:
            errorlog.append(1)
            err += ex['D']
        # i += 1
    # print('Total number of errors: {0}'.format(err))
    return err, errorlog



#using the adaboost model
#returns 1 if poisonous
def poisOredible(learners,weight,features):
    poisonous = -1
    weighted_guess = 0
    i = 0
    for tree in learners:
        guess = HF.useTree(tree,features)
        weighted_guess += guess*weight[i]
        i += 1
        
    if weighted_guess >= 0:
        poisonous = 1
    else:
        poisonous = -1

    return poisonous



###### RUN HERE ############################################################
path_to_data = os.path.join(os.getcwd(), 'pa3_train.csv')

data = HF.datareader(path_to_data)
features= list(data.columns[:-1])
y = data.columns[-1]

path_to_val = os.path.join(os.getcwd(),  'pa3_val.csv')
val_data = HF.datareader(path_to_val)
val_features= list(val_data.columns[:-1])
val_y = val_data.columns[-1]


W_all = [] #all the models
Alpha_all = [] #all the vote weights
what_all = [] #what the model and alpha corresponds to
all_wrong_train = [] #how many wrong guesses on training data
all_wrong_val = []  #how many wrong guesses on validation data

# Part C
depth = 1
learners = [1,2,5,10,15] #number of learners to try
for L in learners:
    print('Running Adaboost with L={} and depth={}'.format(L,depth))
    # W, Alpha = adaboost(S,y,L,1) #run adaboost
    W, Alpha = adaboost(data,features,y,L,depth) #run adaboost
    #save results
    W_all.append(W)
    Alpha_all.append(Alpha)
    what_all.append('L{}d{}'.format(L,depth))
    # path_to_outfile = os.path.join(os.getcwd(), '..', 'output', 'part3', 'TEST_L{}D{}.csv' .format(L,depth))
    #try results on train data
    wrong_train = 0
    for ind,ex in data.iterrows():
        guess = poisOredible(W,Alpha,ex)
        if guess != ex[y]:
            wrong_train += 1
    all_wrong_train.append(wrong_train)
    print('{} wrong on training data'.format(wrong_train))

    #try results on train data
    wrong_val = 0
    for ind,ex in val_data.iterrows():
        guess = poisOredible(W,Alpha,ex)
        if guess != ex[val_y]:
            wrong_val += 1
    all_wrong_val.append(wrong_val)
    print('{} wrong on validation data'.format(wrong_val))


# HF.write_out_tree(tree, path_to_outfile)

# Part E
depth = 2
learners = [6] #number of learners to try
for L in learners:
    print('Running Adaboost with L={} and depth={}'.format(L,depth))
    # W, Alpha = adaboost(S,y,L,1) #run adaboost
    W, Alpha = adaboost(data,features,y,L,depth) #run adaboost
    #save results
    W_all.append(W)
    Alpha_all.append(Alpha)
    what_all.append('L{}d{}'.format(L,depth))
    # path_to_outfile = os.path.join(os.getcwd(), '..', 'output', 'part3', 'TEST_L{}D{}.csv' .format(L,depth))
    #try results on train data
    wrong_train = 0
    for ind,ex in data.iterrows():
        guess = poisOredible(W,Alpha,ex)
        if guess != ex[y]:
            wrong_train += 1
    all_wrong_train.append(wrong_train)
    print('{} wrong on training data'.format(wrong_train))

    #try results on train data
    wrong_val = 0
    for ind,ex in val_data.iterrows():
        guess = poisOredible(W,Alpha,ex)
        if guess != ex[val_y]:
            wrong_val += 1
    all_wrong_val.append(wrong_val)
    print('{} wrong on validation data'.format(wrong_val))

# Print Result Summary
print('\nRun Complete')
for i in range(len(what_all)):
    print('{}: wrong_train: {}%, wrong_val: {}%'.format(what_all[i],\
        1-(all_wrong_train[i]/len(data)),\
            1-(all_wrong_val[i]/len(val_data))))

# Run best on test dataset
best_adaboost = all_wrong_val.ind(min(all_wrong_val))
print('Best Adaboost with {}'.format(what_all[best_adaboost]))
#select best tree/alpha
W = W_all[best_adaboost]
Alpha = Alpha_all[best_adaboost]

#get test data
path_to_test = os.path.join(os.getcwd(),  'pa3_test.csv')
test_data = HF.datareader(path_to_test)
test_features= list(test_data.columns[:])

#make guesses with test data
y_guess = []
for ind,ex in test_data.iterrows():
    guess = poisOredible(W,Alpha,ex)
    y_guess.append(guess)

#save test data
path_to_outfile = os.path.join(os.getcwd(), 'pa3_test_predictions.csv')
df = pd.DataFrame(y_guess)
df.to_csv(path_to_outfile, ind=False, na_rep="None")